msg_reply.moyu_calendar_forhttp = {
    keyword = {
        prefix = { "摸鱼人日历" }
    },
    echo = { lua = "moyu_calendar_forhttp" }
}