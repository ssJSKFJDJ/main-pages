msg_reply.reborn = {
    keyword = {
        prefix = { "reborn" }
    },
    echo = { lua = "reborn" }
}