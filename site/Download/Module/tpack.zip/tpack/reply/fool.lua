msg_reply.fool = {
    keyword = {
        prefix = { "你笨笨" }
    },
    echo = { lua = "fool" }
}