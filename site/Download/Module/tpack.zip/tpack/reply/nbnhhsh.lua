msg_reply.en = {
    keyword = {
        prefix = { "??" }
    },
    echo = { lua = "en" }
}

msg_reply.zh = {
    keyword = {
        prefix = { "？" }
    },
    echo = { lua = "zh" }
}