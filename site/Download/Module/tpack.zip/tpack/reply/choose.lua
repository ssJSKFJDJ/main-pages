msg_reply.choose = {
    keyword = {
        prefix = { "选择" }
    },
    echo = { lua = "choose" }
}