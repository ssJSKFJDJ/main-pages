msg_reply.throw_coin = {
    keyword = {
        prefix = { "/throw" }
    },
    echo = { lua = "throw_coin" }
}